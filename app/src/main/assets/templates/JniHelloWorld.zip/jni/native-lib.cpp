#include <string.h>
#include <jni.h>
extern "C"
{
	JNIEXPORT jstring JNICALL Java_$package_name_jni$_MainActivity_stringFromJNI(JNIEnv* env, jobject thiz)
	{
		return env->NewStringUTF("Hello from JNI !");
	}
}
